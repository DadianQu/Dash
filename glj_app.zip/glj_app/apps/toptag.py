from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import pathlib
from app import app


PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

df = pd.read_csv(DATA_PATH.joinpath("df.csv"))
df.dropna(subset=['senti'],inplace=True)
df['text'] = df['text'].str[:20]

layout = html.Div([
    html.H1('Department Vs Tags', style={"textAlign": "center"}),

    html.Div([
        html.Div(dcc.Dropdown(
            id='dept-dropdown', value='AccountingIT', clearable=False,
            placeholder='Choose the department',
            options=[{'label': x, 'value': x, 'disabled':False} for x in df['Dept'].unique()]
        )),
        html.Br(),
        html.Div(dcc.Dropdown(
            id='senti-dropdown', value='Positive', clearable=False,
            placeholder='Choose the sentiment',
            options=[{'label': x, 'value': x} for x in df['senti'].unique()]
        )),
    ]),

    dcc.Graph(id='my-bar', figure={}),
])


@app.callback(
    Output(component_id='my-bar', component_property='figure'),
    [Input(component_id='dept-dropdown', component_property='value'),
     Input(component_id='senti-dropdown', component_property='value')]
)
def display_value(dept_chosen, senti_chosen):
    df_fltrd = df[(df['Dept'] == dept_chosen) & (df['senti'] == senti_chosen)]
    df_fltrd = df_fltrd.groupby(['tag']).count().reindex()
    df_fltrd.rename(columns={'liked': 'Counts'}, inplace=True)
    fig = px.bar(
        df_fltrd,
        x=df_fltrd.index,
        y = df_fltrd['Counts'],
        opacity=0.9,
        orientation="v",
        barmode='relative', #overlay, group, relative
        color_discrete_sequence= ["lightblue","pink","yellow"],
        #color_discrete_map={} spcify whihc color to which
        #color_continuous_scale=px.colors.diverging.Picnic for color option\
        #range_color=[1,10000]
        text = 'Counts',
        #hover_name = '', new data when you hover
        #hover_data=[''],
        #custom_data=[''],
        labels = {"tag":"Tag Used", "Counts":"Frequency"},
        title = 'Tags Vs Frequency',
        # width=1400,
        height = 700,
        template = 'seaborn'

        # animation_frame='date',
        # range_y=[0,9000],
        # category_orders={'year':[2001,2002,2003,2004]}
        )
    # fig.layout.updatemenus[0].buttons[0].args[1]['frame']['duration'] =1000
    # fig.layout.updatemenus[0].buttons[0].args[1]['transition']['duration'] =1000
    fig.update_layout(
        # uniformtext_minsize = 14,
        # uniformtext_mode = 'hide',
        # legend = {'x':0,'y':1.0},
        xaxis={'categoryorder': 'total descending'}),
    fig.update_traces(
        texttemplate = '%{text:.2s}',textposition = 'outside'
       # ,width=[.3,.3,.3,.6]
    )
    return fig