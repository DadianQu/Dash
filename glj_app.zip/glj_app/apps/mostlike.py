from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import pathlib
from app import app

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()


df = pd.read_csv(DATA_PATH.joinpath("df.csv"))
df = df[df['senti'] != None]
df['text'] = df['text'].str[:20]


df1 = df.nlargest(5, 'liked')
fig2 = px.bar(data_frame=df1, x = 'text', y = 'liked',template = 'seaborn',text = 'liked',color_discrete_sequence= ["lightblue","pink","yellow"],height = 700)
fig2.update_traces(
    texttemplate='%{text:.2s}', textposition='outside'
    # ,width=[.3,.3,.3,.6]
)



layout = html.Div([
    html.H1('Most liked Post', style={"textAlign": "center"}),
    dcc.Graph(id = 'qq', figure=fig2),

    html.H2('Most liked Post (Dept Level)', style={"textAlign": "center"}),
    html.Div([
        dcc.Slider(3, 10, 1, id='choose', value=5)
    ]),
    html.Br(),
    html.Div([
        dcc.Dropdown(
            id = 'dept-dropdown', value = 'AccountingIT', clearable = False,
    options=[{'label': x, 'value': x, 'disabled':False} for x in df['Dept'].unique()]
        )
    ]),
    dcc.Graph(id ='dept-graph', figure={})
]
)
# @app.callback(
#     Output(component_id='qq', component_property='figure')
# )
# def display_value_individual():
#     df1 = df.nlargest(5, 'liked')
#     fig1 = px.bar(data_frame=df1,x='text',y ='liked')
#     return fig1


@app.callback(
    Output(component_id='dept-graph', component_property='figure'),
    [Input(component_id='choose', component_property='value'),
     Input(component_id='dept-dropdown', component_property='value')]
)
def display_value_individual(value, dept_chosen):
    df2 = df[df['Dept'] == dept_chosen]
    df3 = df2.nlargest(value, 'liked')
    fig2 = px.bar(
        data_frame=df3, x='text',y ='liked',template = 'seaborn',text = 'liked',color_discrete_sequence= ["lightblue","pink","yellow"],height = 700
    )
    fig2.update_traces(
        texttemplate = '%{text:.2s}',textposition = 'outside'
       # ,width=[.3,.3,.3,.6]
    )
    return fig2