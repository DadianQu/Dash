import plotly.express as px
from dash import dcc, html
import pandas as pd
import numpy as np
import pathlib

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

df = pd.read_csv(DATA_PATH.joinpath("df.csv"))
df.dropna(subset=['senti'],inplace=True)



fig = px.sunburst(
    data_frame= df,
    path = ['Dept', "senti", "tag"],
    color= "Dept",
    color_discrete_sequence=px.colors.qualitative.Pastel,
    maxdepth = 2 #How many level of diagrams you wanna see
    #,color_continuous_scale= continous color to show data
    #,branchvalues='total' #remainder
    ,hover_name = 'Dept'
    # ,hover_data={'Dept': False} # show or not in the pie hover
    #  ,title = 'Details of Tags/Sentiment over Dept'
    # ,template='ggplot2'
    ,width= 2000
    ,height =1000
)

print (type(fig))

fig.update_traces(textinfo = 'label+percent parent') #each sub part will be 100% label +percent entry
fig.update_layout(margin=dict(t=0,l=0,r=0,b=0))





layout = html.Div([
    html.H1('Department Vs.Senti Vs. Tag ', style={"textAlign": "center"}),

    html.Div([
    dcc.Graph(id='my-bar', figure=fig)
 ])

])



