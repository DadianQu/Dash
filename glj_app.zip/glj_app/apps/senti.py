from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import pathlib
from app import app
from datetime import datetime as dt

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

df = pd.read_csv(DATA_PATH.joinpath("df.csv"))
# df['date'] = pd.to_datetime(df['date']).dt.date
df = df.head(500)

layout = html.Div([
    html.H1('Sentiment Timeline', style={"textAlign": "center"}),

    html.Div([
        # html.Div(dcc.DatePickerRange(
        #     id='date', initial_visible_month=dt(1999, 8, 5),min_date_allowed=dt(1999,7,15),max_date_allowed=dt(2022,7,15),
        #     start_date=dt(2001,7,15).date(), end_date=dt(2063,7,15).date()
        # )),

        html.Div(dcc.Checklist(
            id='checklist', value=['AccountingIT','FinanceIT'],
            persistence=True, persistence_type='memory',
            options=[{'label': x, 'value': x, 'disabled':False} for x in df['Dept'].unique()]
        )),
    ]),

    dcc.Graph(id='my-line', figure={}),
])



@app.callback(
Output(component_id='my-line', component_property='figure'),
Input(component_id='checklist', component_property='value')
# Input(component_id='date', component_property='start_date'),
# Input(component_id='date', component_property='end_date')
)
def display_value(dept_chosen):
    if len(dept_chosen) < 1:
        fig1 = px.line(df,x='date',y='senti_score',height = 700,template = 'seaborn')
        return fig1
    else:
        df1 = df[df['Dept'].isin(dept_chosen)]
        fig2 = px.line(df1, x='date', y='senti_score', color='Dept',height = 700,template = 'seaborn')
        return fig2