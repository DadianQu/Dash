from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px
import pandas as pd
import pathlib
from app import app
from wordcloud import WordCloud, STOPWORDS
import pandas as pd
import matplotlib.pyplot as plt
import mpld3


PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()


df = pd.read_csv(DATA_PATH.joinpath("df.csv"))
df = df.head(200)

app.layout = html.Div([
    html.H1('WordCloud', style={"textAlign": "center"}),

    html.Div([
        html.Div(dcc.Dropdown(
            id='TopWords', value=20, clearable=False,
            placeholder='How many words do you wanna see?',
            options=[20,100,200,500]
        )),
        html.Br(),
        html.Div(dcc.Dropdown(
            id='dept', value='AccountingIT', clearable=False,
            placeholder='Choose the sentiment',
            options=[{'label': x, 'value': x} for x in df['Dept'].unique()]
        )),
    ]),

    dcc.Graph(id='my-bar', figure={}),
])


@app.callback(
    Output('my-bar', 'figure'),
    [Input('TopWords', 'value'),
    Input('dept','value')]
)
def wordcloud(n,dept):

    df1 = df[df['Dept'] == dept]
    text = " ".join(content for content in df1.text)

    wordcloud = WordCloud(max_words=n, stopwords=STOPWORDS).generate(text)
    fig = plt.figure()
    plt.imshow(wordcloud)
    plt.axis("off")
    fig1 = mpld3.fig_to_html(fig)
    return fig1



if __name__ == '__main__':
    app.run_server(port = 9999)