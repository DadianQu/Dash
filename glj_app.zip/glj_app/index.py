import dash_auth.auth
from dash import dcc, html
from dash.dependencies import Input, Output
import dash_auth

# Connect to main app.py file
from app import app
from app import server

# Connect to your app pages
from apps import toptag, mostlike, senti, sun


auth = dash_auth.BasicAuth(
    app,
    {'glj':'glj'
    }

)


app.layout = html.Div([
    dcc.Location(id='url', refresh=False, pathname=''),
    html.Div([
        dcc.Link('|--Top Tags--|', href='/apps/toptag'),
        dcc.Link('--Most Liked--|', href='/apps/mostlike'),
        dcc.Link('--Timeline--|', href='/apps/senti'),
        dcc.Link('--Detailed--|', href='/apps/sun')
    ]),
    html.Div(id='page-content', children=[])
])


@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname == '/apps/toptag':
        return toptag.layout
    if pathname == '/apps/mostlike':
        return mostlike.layout
    if pathname == '/apps/senti':
        return senti.layout
    if pathname == '/apps/sun':
        return sun.layout
    else:
        return toptag.layout





if __name__ == '__main__':
    app.run_server(debug = False)